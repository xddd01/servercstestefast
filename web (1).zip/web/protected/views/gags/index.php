<style>
tr:hover {cursor:pointer;}
</style>
<?php if(Webadmins::checkAccess('bans_edit')):?>
	<a class="btn btn-warning" href="gags/create?s=<?=(isset($_GET['s']) ? $_GET['s'] : '')?>" style="display: block; margin: 10px auto; width: 150px">Добави нов GAG</a>
<?php endif; ?>

<?php
$page = 'GAG-листа';
$this->pageTitle = Yii::app()->name . ' - ' . $page;

$this->breadcrumbs=array(
	$page,
);

Yii::app()->clientScript->registerScript('search', "
$('.search-form form').submit(function(){
    $.fn.yiiGridView.update('gags-grid', {
        data: $(this).serialize()
    });
    return false;
});
");

$this->renderPartial('_search',array(
    'model'=>$model,
));

$this->widget('bootstrap.widgets.TbGridView', array(
    'type'=>'striped bordered condensed',
	'id'=>'gags-grid',
    'dataProvider'=>isset($_GET['Gags']) ? $model->search() : $dataProvider,
    'enableSorting' => array('create_time', 'name', 'admin_name', 'reason'),
	'summaryText' => 'Shown with {start} on {end} gag from {count}. Page {page} from {pages}',
	'htmlOptions' => array(
		'style' => 'width: 100%'
	),
	'rowHtmlOptionsExpression'=>'array(
		"id" => "gag_$data->id",
		"class" => ($data->expired_time < time() && $data->expired_time) ? "bantr success" : "bantr",
		"onclick" => "document.location.href=\'".Yii::app()->createUrl("/gags/view", array("id" => $data->id, "s" => isset($_GET["s"]) ? $_GET["s"] : ""))."\'"
	)',
	'pager' => array(
		'class'=>'bootstrap.widgets.TbPager',
		'displayFirstAndLast' => true,
	),
    'columns'=>array(
        array(
            'header' => 'Дата',
            'name' => 'create_time',
            'value' => 'date("d.m.Y H:i", $data->create_time)',
            'htmlOptions' => array('style' => 'width:100px'),
        ),
		array(
			'header' => 'Ник',
			'type' => 'raw',
			'name' => 'name',
			'value' => '$data->country . " " . CHtml::encode($data->name)'
		),

        array(
            'header' => 'Админ',
            'type' => 'raw',
            'name' => 'admin_name',
            'value' => '$data->admin ? CHtml::link(CHtml::encode(mb_substr($data->admin_name, 0, 18, "UTF-8")), Yii::app()->urlManager->baseUrl . "/amxadmins/#admin_" . $data->admin->id) : CHtml::encode(mb_substr($data->admin_name, 0, 18, "UTF-8"))',
            'htmlOptions' => array(
                'style' => 'width: 130px'
            )
        ),
        array(
            'header' => 'Срок',
            'value' => '($data->expired_time != 0) ? ($data->expired_time != -1 ? date("d.m.Y H:i", $data->expired_time) : "Разблокиран") : "Завинаги"',
            'htmlOptions' => array('style' => 'width:150px'),
        ),

        array(
            'header' => 'Причина',
            'name' => 'reason',
            'value' => '$data->reason ? CHtml::encode($data->reason) : ""',
            'htmlOptions' => array('style' => 'width:100px'),
        ),
        array(
            'header' => 'Тип',
            'name' => 'block_type',
            'value' => 'Gags::getBlockType($data->block_type)',
            'htmlOptions' => array('style' => 'width:100px'),
        ),
        array(
            'class'=>'bootstrap.widgets.TbButtonColumn',
            'template' => '{delete} {update}',
            'htmlOptions' => array('style' => 'width:30px'),
            'visible' => Webadmins::checkAccess('bans_edit')
        )
	),
));
?>