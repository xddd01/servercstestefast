<div class="form">

    <?php

    /** @var TbActiveForm $form */
    /** @var Gags $model */
    $form = $this->beginWidget('bootstrap.widgets.TbActiveForm', array(
        'action' => Yii::app()->createUrl($this->route, ["id" => $model->id]),
        'id' => 'gags-form',
        'type' => 'horizontal',
        'enableAjaxValidation' => TRUE,
    ));
    ?>
    <style>
        .required {
            color: red;
        }
    </style>
    <p class="note">Маркирани полета <span class="required">*</span> необходимо за попълване.</p>
    <fieldset>
        <?php echo $form->errorSummary($model); ?>

        <?php echo $form->textFieldRow($model, 'name', array('size' => 60, 'maxlength' => 100)); ?>

        <?php echo $form->textFieldRow($model, 'steamid', array('size' => 35, 'maxlength' => 35)); ?>
        <?php echo $form->textFieldRow($model, 'ip', array('size' => 32, 'maxlength' => 32)); ?>
        <?php echo $form->textFieldRow($model, 'reason', array('size' => 32, 'maxlength' => 32)); ?>

        <?php echo $form->dropDownListRow($model, 'block_type', Gags::getBlockTypes(), array('empty' => 'Изберете тип')); ?>
        <?php echo $form->dropDownListRow($model, 'expired_time', Gags::getBanLenght(), array('empty' => 'Срок на бана')); ?>

        <?php if (!$model->isNewRecord) : ?>
            <div class="control-group">
                <label class="control-label" for="Gags_add_time">Добавете към крайния срок</label>
                <div class="controls">
                    <input name="add_time" id="Gags_add_time" type="checkbox">
                </div>
            </div>
        <?php endif; ?>

    </fieldset>
    <div class="form-actions">
        <?php $this->widget('bootstrap.widgets.TbButton', array(
            'buttonType' => 'submit',
            'type' => 'primary',
            'label' => $model->isNewRecord ? 'Създайте' : 'Обнови'));
        ?>
    </div>

    <?php $this->endWidget(); ?>

</div>
