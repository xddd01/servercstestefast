<?php $page = 'GAG-листа';
$this->pageTitle = Yii::app()->name . ' - ' . $page . ' - GAG играч ' . $model->name;
$this->breadcrumbs=array(
	$page=>array('index', 's'=>$_GET['s']),
	$model->name,
);
$description = '';
if($model->expired_time == '-1') {
    $description = 'Разблокиран';
} else {
    $length = $model->expired_time;
	$currenttime = time();
	if($length < $currenttime) {
		 $description .= '(Просрочен)';
	}else{
		 $description = date("d.m.Y - H:i:s", $model->expired_time);
	}
}
?>

<div style="float: right">
	<?php if(Webadmins::checkAccess('bans_edit', $model->admin_name)): 	echo CHtml::link('<i class="icon-edit"></i>', $this->createUrl('/gags/update', array('id' => $model->id, 's' => $_GET['s'])),
		array(
			'rel' => 'tooltip',
			'title' => 'Редактиране',
		)
	);
	endif;?>
	&nbsp;
	<?php if(Webadmins::checkAccess('bans_unban', $model->admin_name) && !$model->unbanned): echo CHtml::ajaxLink('<i class="icon-remove"></i>', $this->createUrl('/gags/unban', array('id' => $model->id, 's' => $_GET['s'])),
		array(
			'type' => 'post',
			'beforeSend' => 'function() {if(!confirm("Премахни GAG '.$model->name.'?")) {return false;} }',
			'success' => 'function(data) {alert(data); document.location.href="'.$this->createUrl('/gags/index').'";}'
		),
		array(
			'rel' => 'tooltip',
			'title' => 'Премахни GAG',
		)
	);
	endif;?>
	&nbsp;
	<?php if(Webadmins::checkAccess('bans_delete', $model->admin_name)): echo CHtml::ajaxLink('<i class="icon-trash"></i>', $this->createUrl('/gags/delete', array('id' => $model->id, 's' => $_GET['s'], 'ajax' => 1)),
		array(
			'type' => 'post',
			'beforeSend' => 'function() {if(!confirm("Изтрий GAG?")) {return false;} }',
			'success' => 'function() {alert("GAG изтрит"); document.location.href="'.$this->createUrl('/gags/index').'"}'
		),
		array(
			'rel' => 'tooltip',
			'title' => 'Изтрий GAG',
		)
	);
	endif;?>
</div>

<?php $this->widget('bootstrap.widgets.TbDetailView', array(
	'data'=>$model,
	'type' => array('condensed', 'bordered'),
	'htmlOptions' => array('style'=>'text-align: left'),
	'attributes'=>array(
		array(
			'name' => 'ip',
			'type' => 'raw',
			'value' => $model->ip,
			'visible' => ($ipaccess)
		),
		array(
			'name' => 'steamid',
			'type' => 'raw',
			'value' => $model->steamid,
			'visible' => ($ipaccess)
		),
		'name',
		'admin_name',
		array(
            'name' => 'create_time',
            'value' => date('d.m.Y - H:i:s', $model->create_time),
        ),
        array(
            'name' => 'block_type',
            'value' => Gags::getBlockType($model->block_type),
        ),
		array(
            'name' => 'expired_time',
            'type' => 'raw',
            'value' => isset($description) ? $description : '',
        ),
	),
)); ?>