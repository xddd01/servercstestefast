<?php
$page = 'GAG-листа';
$sub_page = 'Редактиране';
$this->pageTitle = Yii::app()->name . ' :: Админ център - Редактиране на забрана на играча ' . $model->name;
$this->breadcrumbs = array(
    $page => array('index'),
    $sub_page => [],
    $model->name,
);
?>

<?php echo $this->renderPartial('_form', array('model' => $model)); ?>