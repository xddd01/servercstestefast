<?php $this->pageTitle = Yii::app()->name . ' :: Админ център - Добави GAG'; ?>

<h2>Добави GAG</h2>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
