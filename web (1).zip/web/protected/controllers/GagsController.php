<?php

/**
 * Class GagsController
 */
class GagsController extends Controller
{
    /**
     * @var string
     */
    public $layout = '//layouts/column1';

    /**
     * @return array
     */
    public function filters()
    {
        return array(
            'accessControl',
            'postOnly + delete'
        );
    }

    /**
     * @return array
     */
    public function actions()
    {
        return array(
            'captcha' => array(
                'class' => 'CCaptchaAction'
            )
        );
    }

    /**
     * @param $id
     * @throws CHttpException
     */
    public function actionUnban($id)
    {
        $model = $this->loadModel($id);

        // Проверка прав
        if (!Webadmins::checkAccess('bans_unban', $model->admin_name)) {
            throw new CHttpException(403, "Нямате достатъчно права");
        }

        $model->expired_time = '-1';

        if ($model->save(FALSE)) {
            Yii::app()->end('Играчът е забранен');
        }

        Yii::app()->end(CHtml::errorSummary($model));
    }

    /**
     * @param $id
     * @throws CHttpException
     */
    public function actionDelete($id)
    {
        $model = $this->loadModel($id);

        if (!Webadmins::checkAccess('bans_delete')) {
            throw new CHttpException(403, "Нямате достатъчно права");
        }

        $model->delete();

        if (!isset($_GET['ajax'])) {
            $this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
        }
    }

    /**
     * @throws CHttpException
     */
    public function actionCreate()
    {
        // Проверка прав
        if (!Webadmins::checkAccess('bans_add')) {
            throw new CHttpException(403, "Нямате достатъчно права");
        }

        $model = new Gags;
        $model->setTable($_GET['s']);
        // Аякс проверка формы
        $this->performAjaxValidation($model);

        if (isset($_POST['Gags'])) {
            $model->attributes = $_POST['Gags'];
            $model->admin_name = 'От сайта';
            $model->admin_steamid = 'От сайта';
            $model->admin_ip = '127.0.0.1';
            $model->create_time = time();
            if ($model->save()) {
                $this->redirect(array('view', 'id' => $model->id));
            }
        }

        $this->render('create', array(
            'model' => $model,
        ));
    }

    /**
     * @param $id
     * @throws CHttpException
     */
    public function actionUpdate($id)
    {
        /** @var Gags $model */
        $model = $this->loadModel($id);

        // Проверка прав
        if (!Webadmins::checkAccess('bans_edit', $model->admin_name)) {
            throw new CHttpException(403, "Нямате достатъчно права");
        }

        // Аякс проверка формы
        // $this->performAjaxValidation($model);

        // Сохраняем форму
        if (isset($_POST['Gags'])) {
            $old_time = ($model->expired_time - $model->create_time) / 60;
            $model->attributes = $_POST['Gags'];
            if ($_POST['add_time']) {
                $model->setAttribute('expired_time', (int)$old_time + $_POST['Gags']['expired_time']);
            }
            if ($model->save()) {
                $this->redirect(array('view', 'id' => $model->id));
            }
        }

        $this->render('update', array(
            'model' => $model,
        ));
    }

    /**
     * @param $id
     * @throws CHttpException
     */
    public function actionView($id)
    {
        $model = Gags::model()->setTable($_GET['s'])->with('admin')->findByPk($id);
        if ($model === null) {
            throw new CHttpException(404, 'Исканата страница не съществува.');
        }
        $ipaccess = Webadmins::checkAccess('ip_view');

        $this->render('view', array(
            'ipaccess' => $ipaccess,
            'model' => $model,
        ));
    }

    /**
     *
     */
    public function actionIndex()
    {
        /** @var CHttpRequest $request */
        $request = Yii::app()->request;
        //$model=new Gags('search');
        $model = Gags::model()->setTable($request->getQuery('s', null))->with('admin');
        $model->unsetAttributes();
        if (isset($_GET['Gags'])) {
            $model->attributes = $_GET['Gags'];
        }

        $dataProvider = new CActiveDataProvider('Gags', array(
                'pagination' => array(
                    'pageSize' => Yii::app()->config->bans_per_page),
                'sort' => array(
                    'defaultOrder' => '`create_time` DESC',
                    'attributes' => array(
                        'create_time',
                        'name',
                        'admin_name',
                        'reason',
                        'block_type'
                    )
                )
            )
        );

        $this->render('index', array(
            'dataProvider' => $dataProvider,
            'servers' => Serverinfo::model()->findAll(),
            'model' => $model
        ));

    }

    /**
     * @param $id
     * @return mixed
     * @throws CHttpException
     */
    public function loadModel($id)
    {
        $model = Gags::model()->setTable($_GET['s'])->with('admin')->findByPk($id);
        if ($model === null) {
            throw new CHttpException(404, 'Записът не е намерен.');
        }
        return $model;
    }

    /**
     * @param $model
     */
    protected function performAjaxValidation($model)
    {
        if (isset($_POST['ajax']) && $_POST['ajax'] === 'gags-form') {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }
}
