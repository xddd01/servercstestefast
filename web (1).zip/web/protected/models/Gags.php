<?php

/**
 * @property integer $id ID бана
 * @property string $steamid Стим игрока
 * @property string $name Ник игрока
 * @property string $ip IP игрока
 * @property string $admin_name Ник админа
 * @property string $admin_steamid Стим админа
 * @property string $admin_ip
 * @property integer $create_time Дата бана
 * @property integer $expired_time Дата истечения бана
 * @property integer $reason Причина
 * @property string $block_type
 *
 * The followings are the available model relations:
 * @property Amxadmins $admin
 */
class Gags extends CActiveRecord
{
    /**
     * @var null
     */
    public $country = null;
    /**
     * @var string
     */
    public $table = 'ucc_gag';

    /**
     * @param string $className
     * @return CActiveRecord|mixed
     */
    public static function model($className = __CLASS__)
    {
        return parent::model($className);
    }

    /**
     * @return string
     */
    public function tableName()
    {
        return $this->table;
    }

    /**
     * @param null $sid
     * @return $this
     */
    public function setTable($sid = null)
    {
        if ($sid) {
            $server = Serverinfo::model()->findByPk($sid);
            if ($server->gags) {
                $this->table = $server->gags;
            }
        }


        return $this;
    }

    /**
     * @return array
     */
    public function rules()
    {
        return array(
            array('name, admin_name, reason, expired_time, ip, steamid, block_type', 'required'),
            array('ip', 'match', 'pattern' => '/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/'),
            array('steamid', 'match', 'pattern' => '/^(STEAM|VALVE)_([0-9]):([0-9]):\d{1,21}$/'),
            array('id, steamid, name, ip, admin_name, admin_steamid, reason, create_time, expired_time', 'safe', 'on' => 'search'),
        );
    }

    /**
     * @return array
     */
    public function relations()
    {
        return array(
            'admin' => array(
                self::HAS_ONE,
                'Amxadmins',
                '',
                'on' => '`admin`.`steamid` = `t`.`admin_name` OR '
                    . '`admin`.`steamid` = `t`.`admin_steamid`'
            )
        );
    }

    /**
     * @return array
     */
    public function attributeLabels()
    {
        return array(
            'id' => 'ID:',
            'ip' => 'IP играч',
            'steamid' => 'Steam играч',
            'name' => 'Ник играч',
            'create_time' => 'Създаден',
            'expired_time' => 'Срок',
            'admin_name' => 'Ник админа',
            'reason' => 'Причина',
            'block_type' => 'Тип блок'
        );
    }

    /**
     * @return bool
     */
    public function getUnbanned()
    {
        return $this->expired_time && ($this->expired_time == '-1' || ($this->create_time + ($this->expired_time * 60)) < time());
    }

    /**
     * @return array
     */
    public static function getBanLenght()
    {
        return array(
            '0' => 'Завинаги',
            '5' => '5 минути',
            '10' => '10 минути',
            '15' => '15 минути',
            '30' => '30 минути',
            '60' => '1 час',
            '120' => '2 часа',
            '180' => '3 часа',
            '300' => '5 часа',
            '600' => '10 часа',
            '1440' => '1 ден',
            '4320' => '3 дена',
            '10080' => '1 седмица',
            '20160' => '2 седмици',
            '43200' => '1 Месец',
            '129600' => '3 месеца',
            '259200' => '6 месеца',
            '518400' => '1 година',
        );
    }

    /**
     * @return bool
     */
    protected function beforeSave()
    {
        $this->expired_time = time() + $this->expired_time * 60;

        return parent::beforeSave();
    }

    /**
     *
     */
    protected function afterFind()
    {
        $country = strtolower(Yii::app()->IpToCountry->lookup($this->ip));
        $this->country = CHtml::image(
            Yii::app()->urlManager->baseUrl
            . '/images/country/'
            . ($country != 'zz' ? $country : 'clear') . '.png'
        );

        return parent::afterFind();
    }

    /**
     * @param $type
     * @return string
     */
    public static function getBlockType($type)
    {
        return self::getBlockTypes()[$type] ?: '-';
    }

    /**
     * @return array
     */
    public static function getBlockTypes()
    {
        return [
            '0' => 'В стаите',
            '1' => 'Чат',
            '2' => 'Микрофон',
            '3' => 'Всичко'
        ];
    }

    /**
     *
     */
    public function afterDelete()
    {
        Syslog::add(Logs::LOG_DELETED, 'Премахнат GAG на играча <strong>' . $this->name . '</strong>');
        return parent::afterDelete();
    }

    /**
     * @return CActiveDataProvider
     */
    public function search()
    {
        $criteria = new CDbCriteria;

        $criteria->compare('t.id', $this->id);
        $criteria->addSearchCondition('t.ip', $this->ip);
        $criteria->addSearchCondition('t.steamid', $this->steamid);
        $criteria->addSearchCondition('t.name', $this->name);
        $criteria->addSearchCondition('t.admin_name', $this->admin_name);
        $criteria->addSearchCondition('t.reason', $this->reason);
        $criteria->addSearchCondition('t.expired_time', $this->reason);

        $criteria->order = '`create_time` DESC';

        return new CActiveDataProvider($this->setTable($_GET['s']), array(
            'criteria' => $criteria,
            'pagination' => array(
                'pageSize' => Yii::app()->config->bans_per_page
            )
        ));
    }
}
